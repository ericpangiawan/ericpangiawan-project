package com.example.id.ac.binus.volutry.model;

public class DetailFormPenerimaan {
    private String idKegiatan;
    private String idFormKegiatan;
    private int gaji;

    public String getIdKegiatan() {
        return idKegiatan;
    }

    public void setIdKegiatan(String idKegiatan) {
        this.idKegiatan = idKegiatan;
    }

    public String getIdFormKegiatan() {
        return idFormKegiatan;
    }

    public void setIdFormKegiatan(String idFormKegiatan) {
        this.idFormKegiatan = idFormKegiatan;
    }

    public int getGaji() {
        return gaji;
    }

    public void setGaji(int gaji) {
        this.gaji = gaji;
    }
}
